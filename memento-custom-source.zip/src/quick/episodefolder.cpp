////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2026 Ripose
//
// This file is part of Memento.
//
// Memento is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2 of the License.
//
////////////////////////////////////////////////////////////////////////////////

#include "quick/episodefolder.h"

#include <algorithm>

#include <QCollator>
#include <QCryptographicHash>
#include <QDir>
#include <QFileInfo>
#include <QSettings>
#include <QSet>

#if defined(Q_OS_UNIX) && !defined(Q_OS_MACOS)
#include "util/directoryutils.h"
#endif

namespace
{

constexpr const char *SETTINGS_GROUP = "episode-folders";
constexpr const char *CURRENT_FOLDER = "current-folder";
constexpr const char *WATCHED_FILES = "watched-files";

QSettings makeSettings()
{
#if defined(Q_OS_UNIX) && !defined(Q_OS_MACOS)
    return QSettings(DirectoryUtils::getCacheConfig(), QSettings::NativeFormat);
#else
    return QSettings();
#endif
}

const QSet<QString> VIDEO_EXTENSIONS{
    "3gp", "avi", "flv", "m2ts", "m4p", "m4v", "mkv", "mov", "mp2",
    "mp4", "mpe", "mpeg", "mpg", "mpv", "mts", "ogg", "ogm", "ogv",
    "qt", "ts", "vob", "webm", "wmv"
};

} // namespace

EpisodeFolder::EpisodeFolder(QObject *parent) : QObject(parent)
{
    QSettings settings = makeSettings();
    settings.beginGroup(SETTINGS_GROUP);
    const QString savedFolder = settings.value(CURRENT_FOLDER).toString();
    settings.endGroup();

    if (!savedFolder.isEmpty() && QFileInfo(savedFolder).isDir())
    {
        open(QUrl::fromLocalFile(savedFolder));
    }
}

const QString &EpisodeFolder::folder() const noexcept
{
    return m_folder;
}

QString EpisodeFolder::folderName() const
{
    return QFileInfo(m_folder).fileName();
}

const QStringList &EpisodeFolder::files() const noexcept
{
    return m_files;
}

int EpisodeFolder::totalCount() const noexcept
{
    return m_files.size();
}

int EpisodeFolder::watchedCount() const noexcept
{
    int count = 0;
    for (const QString &file : m_files)
    {
        count += m_watched.contains(file) ? 1 : 0;
    }
    return count;
}

QStringList EpisodeFolder::open(const QUrl &folderUrl)
{
    const QString newFolder = normalizedPath(
        folderUrl.isLocalFile() ? folderUrl.toLocalFile() : folderUrl.toString()
    );
    if (!QFileInfo(newFolder).isDir())
    {
        return {};
    }

    const bool folderWasChanged = m_folder != newFolder;
    m_folder = newFolder;

    QSettings settings = makeSettings();
    settings.beginGroup(SETTINGS_GROUP);
    settings.setValue(CURRENT_FOLDER, m_folder);
    settings.endGroup();

    QDir dir(m_folder);
    const QFileInfoList entries = dir.entryInfoList(
        QDir::Files | QDir::Readable | QDir::NoDotAndDotDot,
        QDir::NoSort
    );

    m_files.clear();
    m_files.reserve(entries.size());
    for (const QFileInfo &entry : entries)
    {
        if (VIDEO_EXTENSIONS.contains(entry.suffix().toLower()))
        {
            m_files.emplaceBack(entry.canonicalFilePath());
        }
    }

    QCollator collator;
    collator.setNumericMode(true);
    collator.setCaseSensitivity(Qt::CaseInsensitive);
    std::sort(
        m_files.begin(),
        m_files.end(),
        [&collator](const QString &left, const QString &right) {
            return collator.compare(
                QFileInfo(left).fileName(),
                QFileInfo(right).fileName()
            ) < 0;
        }
    );

    loadWatched();
    if (folderWasChanged)
    {
        emit folderChanged();
    }
    emit filesChanged();
    emit watchedChanged();
    return m_files;
}

QStringList EpisodeFolder::rescan()
{
    if (m_folder.isEmpty())
    {
        return {};
    }
    return open(QUrl::fromLocalFile(m_folder));
}

bool EpisodeFolder::containsFile(const QString &file) const
{
    return m_files.contains(normalizedPath(file));
}

QString EpisodeFolder::fileName(const QString &file) const
{
    return QFileInfo(normalizedPath(file)).fileName();
}

bool EpisodeFolder::isWatched(const QString &file) const
{
    return m_watched.contains(normalizedPath(file));
}

void EpisodeFolder::setWatched(const QString &file, bool watched)
{
    const QString path = normalizedPath(file);
    if (!m_files.contains(path) || m_watched.contains(path) == watched)
    {
        return;
    }

    if (watched)
    {
        m_watched.emplaceBack(path);
    }
    else
    {
        m_watched.removeAll(path);
    }
    writeWatched();
    emit watchedChanged();
}

QString EpisodeFolder::normalizedPath(const QString &value)
{
    const QUrl url(value);
    const QString localPath = url.isLocalFile() ? url.toLocalFile() : value;
    const QFileInfo info(localPath);
    const QString canonical = info.canonicalFilePath();
    return canonical.isEmpty() ? info.absoluteFilePath() : canonical;
}

QString EpisodeFolder::settingsKey() const
{
    return QString::fromLatin1(
        QCryptographicHash::hash(m_folder.toUtf8(), QCryptographicHash::Sha256)
            .toHex()
    );
}

void EpisodeFolder::loadWatched()
{
    QSettings settings = makeSettings();
    settings.beginGroup(SETTINGS_GROUP);
    settings.beginGroup(settingsKey());
    m_watched = settings.value(WATCHED_FILES).toStringList();
    settings.endGroup();
    settings.endGroup();

    QSet<QString> currentFiles(m_files.begin(), m_files.end());
    m_watched.removeIf([&currentFiles](const QString &file) {
        return !currentFiles.contains(file);
    });
}

void EpisodeFolder::writeWatched() const
{
    QSettings settings = makeSettings();
    settings.beginGroup(SETTINGS_GROUP);
    settings.beginGroup(settingsKey());
    settings.setValue(WATCHED_FILES, m_watched);
    settings.endGroup();
    settings.endGroup();
    settings.sync();
}
