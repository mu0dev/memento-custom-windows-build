////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2022 Ripose
//
// This file is part of Memento.
//
// Memento is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2 of the License.
//
// Memento is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Memento.  If not, see <https://www.gnu.org/licenses/>.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <QJsonArray>
#include <QJsonObject>
#include <QList>
#include <QPair>
#include <QSet>
#include <QString>

/**
 * @brief Builds Anki-compatible glossaries.
 */
class GlossaryBuilder
{
public:
    /**
     * @brief A struct containing info about a files.
     */
    struct FileInfo
    {
        /* The path of the file */
        QString path;

        /* The new name of the file */
        QString name;
    };

    /**
     * @brief Generate an Anki glossary HTML.
     *
     * @param definitions The definitions to add to this glossary.
     * @param basepath The path where all external resources begin.
     * @param[out] fileMap A mapping of files to file names.
     * @return A list of HTML formatted glossary entries.
     */
    [[nodiscard]]
    static QStringList buildGlossary(
        const QJsonArray &definitions,
        QString basepath,
        QSet<FileInfo> &fileMap);

private:
    GlossaryBuilder() {}

    /**
     * @brief Escape a string for use in HTML.
     *
     * @param str The string to escape.
     * @return An HTML escaped string.
     */
    [[nodiscard]]
    static QString escapeHtml(const QString &str);

    /**
     * @brief Convert a structured data key to an HTML data attribute name.
     *
     * @param key The structured data key.
     * @return The HTML data attribute name.
     */
    [[nodiscard]]
    static QString structuredDataAttributeName(const QString &key);

    /**
     * @brief Check if a structured content tag is supported.
     *
     * @param tag The structured content tag to check.
     * @return true if the tag is supported, false otherwise.
     */
    [[nodiscard]]
    static bool isSupportedStructuredTag(const QString &tag);

    /**
     * @brief Add structured data attributes to the string.
     *
     * @param      obj The structured data attributes to parse.
     * @param[out] out The string to append the data attributes to.
     */
    static void addStructuredData(const QJsonObject &obj, QString &out);

    /**
     * @brief Add structured style objects.
     *
     * @param obj The structured style object.
     * @param[out] out The string this style will be appended to.
     */
    static void addStructuredStyle(const QJsonObject &obj, QString &out);

    /**
     * @brief Add string structured content.
     *
     * @param str The string to add.
     * @param[out] out The string this string will be appended to.
     */
    static void addStructuredContentHelper(const QString &str, QString &out);

    /**
     * @brief Add an array of structured content.
     *
     * @param arr The array of structured content.
     * @param basepath The base of the image path.
     * @param[out] out The string this content will be appended to.
     * @param[out] fileMap A mapping of files to filenames.
     */
    static void addStructuredContentHelper(
        const QJsonArray &arr,
        const QString &basepath,
        QString &out,
        QSet<FileInfo> &fileMap);

    /**
     * @brief Add an object of structured content.
     *
     * @param obj The object of structured content.
     * @param basepath The base of the image path.
     * @param[out] out The string this content will be appended to.
     * @param[out] fileMap A mapping of files to filenames.
     */
    static void addStructuredContentHelper(
        const QJsonObject &obj,
        const QString &basepath,
        QString &out,
        QSet<FileInfo> &fileMap);

    /**
     * @brief Parses and outputs structured content to HTML.
     *
     * @param val The JSON value of the structured content.
     * @param basepath The base of the image path.
     * @param[out] out The string this content will be appended to.
     * @param[out] fileMap A mapping of files to filenames.
     */
    static void addStructuredContent(
        const QJsonValue &val,
        const QString &basepath,
        QString &out,
        QSet<FileInfo> &fileMap);

    /**
     * @brief Add an image type object.
     *
     * @param obj The image object.
     * @param basepath The base of the image path.
     * @param[out] out The string this image will be appended to.
     * @param[out] fileMap A mapping of files to filenames.
     */
    static void addImage(
        const QJsonObject &obj,
        const QString &basepath,
        QString &out,
        QSet<FileInfo> &fileMap);

    /**
     * @brief Add a text object to the HTML document.
     *
     * @param obj The text object.
     * @param[out] out The string the formatted text will be appended to.
     */
    static void addText(const QJsonObject &obj, QString &out);

    /**
     * @brief Add a file to the file map and returns its mapped filename.
     *
     * @param basepath The base path all files will be found at.
     * @param path The relative path of the file to add.
     * @param[out] fileMap The map to add the file to.
     */
    static QString addFile(
        QString basepath,
        const QString &path,
        QSet<FileInfo> &fileMap);
};

inline bool operator==(
    const GlossaryBuilder::FileInfo &lhs,
    const GlossaryBuilder::FileInfo &rhs)
{
    return lhs.path == rhs.path && lhs.name == rhs.name;
}

inline size_t qHash(const GlossaryBuilder::FileInfo &key, size_t seed)
{
    return qHash(key.path, seed);
}
