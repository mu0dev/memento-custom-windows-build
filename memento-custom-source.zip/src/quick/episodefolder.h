////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2026 Ripose
//
// This file is part of Memento.
//
// Memento is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2 of the License.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <QObject>
#include <QStringList>
#include <QUrl>

/**
 * @brief Scans an episode folder and persists which videos were watched.
 */
class EpisodeFolder : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString folder READ folder NOTIFY folderChanged)
    Q_PROPERTY(QString folderName READ folderName NOTIFY folderChanged)
    Q_PROPERTY(QStringList files READ files NOTIFY filesChanged)
    Q_PROPERTY(int totalCount READ totalCount NOTIFY filesChanged)
    Q_PROPERTY(int watchedCount READ watchedCount NOTIFY watchedChanged)

public:
    explicit EpisodeFolder(QObject *parent = nullptr);

    [[nodiscard]] const QString &folder() const noexcept;
    [[nodiscard]] QString folderName() const;
    [[nodiscard]] const QStringList &files() const noexcept;
    [[nodiscard]] int totalCount() const noexcept;
    [[nodiscard]] int watchedCount() const noexcept;

    /** Selects and scans a folder. Returns its naturally sorted video files. */
    Q_INVOKABLE QStringList open(const QUrl &folderUrl);

    /** Rescans the selected folder. */
    Q_INVOKABLE QStringList rescan();

    /** Returns true when file belongs to the selected folder's episode list. */
    Q_INVOKABLE bool containsFile(const QString &file) const;

    /** Returns only the file name for display in the episode picker. */
    Q_INVOKABLE QString fileName(const QString &file) const;

    /** Gets or changes the persisted watched state for a folder episode. */
    Q_INVOKABLE bool isWatched(const QString &file) const;
    Q_INVOKABLE void setWatched(const QString &file, bool watched);

signals:
    void folderChanged();
    void filesChanged();
    void watchedChanged();

private:
    [[nodiscard]] static QString normalizedPath(const QString &value);
    [[nodiscard]] QString settingsKey() const;
    void loadWatched();
    void writeWatched() const;

    QString m_folder;
    QStringList m_files;
    QStringList m_watched;
};
